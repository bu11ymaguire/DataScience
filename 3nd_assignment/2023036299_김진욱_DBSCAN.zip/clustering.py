"""
DBSCAN clustering — Programming Assignment #3
표준 라이브러리만 사용 (sys, os).

핵심:
- O(n^2) brute-force region_query 와 KD-tree 기반 region_query 두 경로를 모두 보유.
- 둘 다 같은 dbscan() 본체를 공유 (정확도가 동일함을 코드 레벨에서 보장).
- 기본값은 KD-tree (속도 우위, 결과 동일).
"""

import sys
import os

# ===== 점의 상태 (labels 배열에 들어가는 sentinel) =====
UNVISITED = -2
NOISE = -1


# ===== 1. 데이터 입출력 =====

def read_data(file_path):
    """
    'id\\tx\\ty' 형식 파일을 읽어 [(id_str, x, y), ...] 로 반환.
    """
    points = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            pid = parts[0]
            x = float(parts[1])
            y = float(parts[2])
            points.append((pid, x, y))
    return points


# ===== 2. KD-tree (2D, 표준 라이브러리만으로 직접 구현) =====

def build_kdtree(points, indices, depth=0):
    """
    2D KD-tree 빌드. 노드는 [idx, axis, left, right] 리스트.
    - axis = 0 (x) / 1 (y) 가 깊이에 따라 교대로 변환된다.
    - mid = 정렬된 indices 의 중앙값을 노드로, 좌/우는 재귀 빌드.
    잎은 None.
    """
    if not indices:
        return None
    axis = depth & 1
    indices.sort(key=lambda i: points[i][axis + 1])  # points[i] = (id, x, y)
    mid = len(indices) // 2
    return [
        indices[mid],
        axis,
        build_kdtree(points, indices[:mid], depth + 1),
        build_kdtree(points, indices[mid + 1:], depth + 1),
    ]


def _kdtree_radius(points, node, qx, qy, eps, eps_sq, out):
    """
    (qx, qy) 로부터 거리 <= eps 인 모든 점 인덱스를 out 리스트에 추가.
    분기 거리가 eps 보다 클 경우 반대편 서브트리는 가지치기 (pruning).
    """
    if node is None:
        return
    idx, axis, left, right = node
    px = points[idx][1]
    py = points[idx][2]
    dx = px - qx
    dy = py - qy
    if dx * dx + dy * dy <= eps_sq:
        out.append(idx)

    # 분기 축 기준 차이
    diff = (qx - px) if axis == 0 else (qy - py)
    if diff <= 0:
        first, second = left, right
    else:
        first, second = right, left

    _kdtree_radius(points, first, qx, qy, eps, eps_sq, out)
    # 반대편은 (수직 거리)^2 <= eps^2 일 때만 (즉, |diff| <= eps)
    if diff * diff <= eps_sq:
        _kdtree_radius(points, second, qx, qy, eps, eps_sq, out)


# ===== 3. region_query 두 가지 구현 =====

def region_query_brute(points, i, eps_sq):
    xi = points[i][1]
    yi = points[i][2]
    neighbors = []
    for j in range(len(points)):
        dx = points[j][1] - xi
        dy = points[j][2] - yi
        if dx * dx + dy * dy <= eps_sq:
            neighbors.append(j)
    return neighbors


def region_query_kd(points, kdtree, i, eps, eps_sq):
    qx = points[i][1]
    qy = points[i][2]
    out = []
    _kdtree_radius(points, kdtree, qx, qy, eps, eps_sq, out)
    return out


# ===== 4. DBSCAN 본체 =====

def dbscan(points, eps, min_pts, use_kdtree=True, order=None):
    """
    표준 DBSCAN. labels 와 raw 클러스터 수를 반환.

    use_kdtree : True 이면 KD-tree 기반 region_query, False 이면 brute-force.
                 둘 다 같은 outer-loop / 같은 BFS 로직을 공유하므로 결과는 동일해야 한다.
    order      : 외부 루프의 점 방문 순서. None 이면 입력 순서(range(n)).
    """
    eps_sq = eps * eps
    n = len(points)

    if use_kdtree:
        kdtree = build_kdtree(points, list(range(n)))
        def query(idx):
            return region_query_kd(points, kdtree, idx, eps, eps_sq)
    else:
        def query(idx):
            return region_query_brute(points, idx, eps_sq)

    labels = [UNVISITED] * n
    cluster_id = 0

    if order is None:
        order = range(n)

    for i in order:
        if labels[i] != UNVISITED:
            continue
        neighbors = query(i)
        if len(neighbors) < min_pts:
            labels[i] = NOISE
            continue

        # i 는 코어 → 새 클러스터 시드
        labels[i] = cluster_id
        seeds = list(neighbors)
        k = 0
        while k < len(seeds):
            q = seeds[k]
            k += 1
            if labels[q] == NOISE:
                labels[q] = cluster_id          # border 흡수
            elif labels[q] == UNVISITED:
                labels[q] = cluster_id
                q_neighbors = query(q)
                if len(q_neighbors) >= min_pts:
                    seeds.extend(q_neighbors)   # q 도 코어
        cluster_id += 1

    return labels, cluster_id


# ===== 5. 후처리 / 출력 =====

def select_top_n_clusters(labels, num_clusters, n):
    """
    raw 클러스터 수가 n 보다 많으면 size 가 작은 (m-n) 개를 NOISE 로 강등.
    살아남은 클러스터는 0..n-1 의 새 ID 로 재라벨링.
    """
    sizes = [0] * num_clusters
    for lab in labels:
        if lab >= 0:
            sizes[lab] += 1

    order = sorted(range(num_clusters), key=lambda c: -sizes[c])
    keep = set(order[:n])

    remap = {}
    new_id = 0
    for c in order:
        if c in keep:
            remap[c] = new_id
            new_id += 1

    new_labels = []
    for lab in labels:
        if lab >= 0 and lab in remap:
            new_labels.append(remap[lab])
        else:
            new_labels.append(NOISE)
    return new_labels, new_id


def write_clusters(input_path, points, new_labels, num_kept, requested_n):
    """
    입력 파일과 같은 폴더에 inputN_cluster_K.txt 들을 생성.

    파일 개수 정책 (need.md 요구사항):
      - 항상 정확히 requested_n 개의 파일을 만든다.
      - 0..num_kept-1 : 실제 클러스터 멤버 ID 가 들어감
      - num_kept..n-1 : 빈 파일 (raw 클러스터가 n 보다 적게 나온 경우 보호)
    """
    base = os.path.basename(input_path)
    stem, _ = os.path.splitext(base)
    out_dir = os.path.dirname(os.path.abspath(input_path))

    buckets = [[] for _ in range(num_kept)]
    for idx, lab in enumerate(new_labels):
        if lab >= 0:
            buckets[lab].append(points[idx][0])

    for k in range(requested_n):
        out_path = os.path.join(out_dir, f"{stem}_cluster_{k}.txt")
        with open(out_path, 'w', encoding='utf-8') as f:
            if k < num_kept:
                for pid in buckets[k]:
                    f.write(pid + '\n')
            # k >= num_kept 이면 빈 파일을 그대로 닫는다.


# ===== 6. CLI =====

def main():
    if len(sys.argv) != 5:
        print("Usage: python clustering.py <input_file> <n> <Eps> <MinPts>")
        sys.exit(1)

    input_file = sys.argv[1]
    n = int(sys.argv[2])
    eps = float(sys.argv[3])
    min_pts = int(sys.argv[4])

    points = read_data(input_file)
    labels, num_clusters = dbscan(points, eps, min_pts, use_kdtree=True)
    new_labels, num_kept = select_top_n_clusters(labels, num_clusters, n)
    write_clusters(input_file, points, new_labels, num_kept, n)

    sizes = [0] * num_kept
    for lab in new_labels:
        if lab >= 0:
            sizes[lab] += 1
    noise = sum(1 for lab in new_labels if lab == NOISE)
    empty_files = n - num_kept
    print(f"input={input_file}  points={len(points)}  "
          f"eps={eps}  MinPts={min_pts}  n_req={n}")
    print(f"raw clusters found = {num_clusters}, kept = {num_kept}, "
          f"empty files padded = {empty_files}")
    print(f"cluster sizes = {sizes}  noise = {noise}")


if __name__ == "__main__":
    main()
